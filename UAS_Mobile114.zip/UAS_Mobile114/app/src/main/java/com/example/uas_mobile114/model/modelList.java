package com.example.uas_mobile114.model;

public class modelList {

    private String namam, harim, jamm, ruang, id;

    public modelList(String namam, String harim, String jamm, String ruang){
        this.namam = namam;
        this.harim = harim;
        this.jamm = jamm;
        this.ruang = ruang;
    }

    public String getNamam() {
        return namam;
    }

    public void setNamam(String namam) {
        this.namam = namam;
    }

    public String getHarim() {
        return harim;
    }

    public void setHarim(String harim) {
        this.harim = harim;
    }

    public String getJamm() {
        return jamm;
    }

    public void setJamm(String jamm) {
        this.jamm = jamm;
    }

    public String getRuang() {
        return ruang;
    }

    public void setRuang(String ruang) {
        this.ruang = ruang;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


}
