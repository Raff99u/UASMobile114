package com.example.uas_mobile114;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.uas_mobile114.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Insert extends AppCompatActivity {

    private EditText nama;
    private Button jam1,submit;
    private Spinner hari, ruang;
    private String jamlist;
    private int tjam,tmin;
    private String id = "";
    private FirebaseFirestore db =FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        nama = findViewById(R.id.namatxt);
        hari = findViewById(R.id.haritxt);
        jam1 = findViewById(R.id.jamtxt);
        ruang= findViewById(R.id.ruangtxt);
        submit= findViewById(R.id.submitbtn);


        //Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(), R.array.Haris, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        hari.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(getApplicationContext(), R.array.Kelass, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ruang.setAdapter(adapter1);


        //btn
        submit.setOnClickListener(view-> {
            if (nama.getText().length()>0){
                saveData(nama.getText().toString(),jamlist,hari.getSelectedItem().toString(),ruang.getSelectedItem().toString());
            } else {
                Toast.makeText(getApplicationContext(), "Silahkan isi semua data!", Toast.LENGTH_SHORT).show();
            }
        });


    }

    //add data
    private void saveData(String nama, String jam, String hari, String kelas) {
        Map<String, Object> matkul = new HashMap<>();
        matkul.put("Mata Kuliah", nama);
        matkul.put("Hari", hari);
        matkul.put("Jam", jam);
        matkul.put("Ruang", kelas);

        db.collection("Mata Kuliah")
                .add(matkul)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(getApplicationContext(), "Berhasil Dimasukkan", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }

    public void popTimePicker(View view) {
        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {

            @Override
            public void onTimeSet(TimePicker view, int selectedHour, int selectedMinute) {
                tjam = selectedHour;
                tmin = selectedMinute;
                jamlist= String.format(Locale.getDefault(), "%02d:%02d",tjam,tmin);
                jam1.setText(String.format(Locale.getDefault(), "%02d:%02d",tjam,tmin));

            }
        };

        //Jam
        TimePickerDialog timePickerDialog = new TimePickerDialog(this, onTimeSetListener, tjam, tmin, true);
        timePickerDialog.setTitle("Pilih Jam Mata Kuliah");
        timePickerDialog.show();
    }


}
