package com.example.uas_mobile114;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.uas_mobile114.fragment.FJadwal;
import com.example.uas_mobile114.fragment.FList;
import com.example.uas_mobile114.fragment.FAbout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarItemView;
import com.google.android.material.navigation.NavigationBarView;


public class MainActivity extends AppCompatActivity implements NavigationBarView.OnItemSelectedListener {

    FJadwal fragmentJadwal = new FJadwal();
    FAbout fragmentAbout = new FAbout();
    FList fragmentMatkul = new FList();
    BottomNavigationView botNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botNav = findViewById(R.id.bottom_navigation);
        botNav.setOnItemSelectedListener(this);
        botNav.setSelectedItemId(R.id.mjadwal);
        botNav.setSelectedItemId(R.id.mmatkul);
        botNav.setSelectedItemId(R.id.mabout);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mjadwal:l:
                getSupportFragmentManager().beginTransaction().replace(R.id.containerLayout, fragmentJadwal).commit();
                return true;
            case R.id.mmatkul:
                getSupportFragmentManager().beginTransaction().replace(R.id.containerLayout, fragmentMatkul).commit();
                return true;
            case R.id.mabout:
                getSupportFragmentManager().beginTransaction().replace(R.id.containerLayout, fragmentAbout).commit();
                return true;
        }
        return false;
    }
}