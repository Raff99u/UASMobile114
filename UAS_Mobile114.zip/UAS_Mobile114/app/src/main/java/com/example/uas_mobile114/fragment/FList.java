package com.example.uas_mobile114.fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.uas_mobile114.Insert;
import com.example.uas_mobile114.R;
import com.example.uas_mobile114.Update;
import com.example.uas_mobile114.adapter.adapterList;
import com.example.uas_mobile114.model.modelList;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class FList extends Fragment {

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private RecyclerView recyclerView;
    private List<modelList> list = new ArrayList<>();
    private adapterList matkulADT;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.flist, container, false);

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.floating_action_button);

        recyclerView = view.findViewById(R.id.rvlist);
        matkulADT = new adapterList(getActivity(), list);
        matkulADT.setDialog(new adapterList.Dialog() {

            @Override
            public void onClick(int pos) {
                final CharSequence[] dialogItem = {"Update","Delete"};
                AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
                dialog.setItems(dialogItem, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i){
                            case 0:
                                Intent intent = new Intent(getActivity(), Update.class);
                                intent.putExtra("Id", list.get(pos).getId());
                                intent.putExtra("Nama", list.get(pos).getNamam());
                                intent.putExtra("Hari", list.get(pos).getHarim());
                                intent.putExtra("Jam", list.get(pos).getJamm());
                                intent.putExtra("Ruang", list.get(pos).getRuang());
                                startActivity(intent);
                                break;
                            case 1:
                                deleteData(list.get(pos).getId());
                                break;

                        }
                    }
                });
                dialog.show();
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(matkulADT);

        fab.setOnClickListener(v -> {
            startActivity(new Intent(getActivity(), Insert.class));
        });
        getData();
        return view;

    }

    @Override
    public void onStart(){
        super.onStart();
        getData();
    }

    private void getData(){
        db.collection("Mata Kuliah")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @SuppressLint("Data Sudah dirubah")
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        list.clear();
                        if (task.isSuccessful()){
                            for(QueryDocumentSnapshot document : task.getResult()){
                                modelList modal = new modelList(document.getString("Mata Kuliah"),
                                        document.getString("Hari"),
                                        document.getString("Jam"),
                                        document.getString("Ruang"));
                                modal.setId(document.getId());
                                list.add(modal);
                            }
                            matkulADT.notifyDataSetChanged();
                        }else{
                            Toast.makeText(getActivity(), "Data gagal di rubah", Toast.LENGTH_SHORT).show();
                        }
                    }

                });
    }

    private void deleteData(String id){
        db.collection("Mata Kuliah").document(id)
                .delete()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (!task.isSuccessful()){
                            Toast.makeText(getActivity(), "Data gagal di hilangkan", Toast.LENGTH_SHORT).show();
                        }
                        getData();
                    }
                });
    }




}
