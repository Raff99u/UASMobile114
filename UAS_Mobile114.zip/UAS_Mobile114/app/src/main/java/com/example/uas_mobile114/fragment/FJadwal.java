package com.example.uas_mobile114.fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.uas_mobile114.R;
import com.example.uas_mobile114.adapter.adapterList;
import com.example.uas_mobile114.model.modelList;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FJadwal extends Fragment{

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private RecyclerView recyclerView;
    private List<modelList> list = new ArrayList<>();
    private adapterList matkulAdapter;

    public FJadwal() {
        // Required empty public constructor
    }

    public static String getCurrentDate(){
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE", new Locale("id","ID"));
        String tanggal = simpleDateFormat.format(c);
        return tanggal;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate
        View view = inflater.inflate(R.layout.fjadwal, container, false);

        recyclerView = view.findViewById(R.id.rvlist);
        matkulAdapter = new adapterList(getActivity(), list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(matkulAdapter);

        getData();
        return view;

    }

    private void getData(){
        db.collection("Mata Kuliah")
                .whereEqualTo("Hari", getCurrentDate())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        list.clear();
                        if (task.isSuccessful()){
                            for(QueryDocumentSnapshot document : task.getResult()){
                                modelList modal = new modelList(document.getString("Mata Kuliah"), document.getString("Hari"), document.getString("Jam"),document.getString("Ruang"));
                                modal.setId(document.getId());
                                list.add(modal);
                            }
                            matkulAdapter.notifyDataSetChanged();
                        }else{
                            Toast.makeText(getActivity(), "Data gagal di Pilih", Toast.LENGTH_SHORT).show();
                        }
                    }

                });
    }

    @Override
    public void onStart(){
        super.onStart();
        getData();
    }


}
