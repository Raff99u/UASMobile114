package com.example.uas_mobile114.adapter;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.uas_mobile114.R;
import com.example.uas_mobile114.model.modelList;


import java.util.List;


public class adapterList extends RecyclerView.Adapter<adapterList.MyVH>{

    private Context context;
    private List<modelList> list;
    private Dialog dialog;

    public interface Dialog{
        void onClick(int pos);
    }

    public void setDialog(Dialog dialog){
        this.dialog = dialog;
    }

    public adapterList(Context context, List<modelList> list){
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list, parent, false);
        return new MyVH(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyVH holder, int position) {
        holder.nama.setText(list.get(position).getNamam());
        holder.hari.setText(list.get(position).getHarim());
        holder.jam.setText(list.get(position).getJamm());
        holder.ruang.setText(list.get(position).getRuang());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    class MyVH extends RecyclerView.ViewHolder{
        TextView nama, hari, jam, ruang;

        public MyVH(@NonNull View itemView){
            super(itemView);
            nama = itemView.findViewById(R.id.namalist);
            hari = itemView.findViewById(R.id.harilist);
            jam = itemView.findViewById(R.id.jamlist);
            ruang= itemView.findViewById(R.id.ruanglist);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (dialog!=null){
                        dialog.onClick(getLayoutPosition());
                    }
                }
            });
        }
    }
}
