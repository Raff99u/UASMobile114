package com.example.uas_mobile114;

import androidx.annotation.NonNull;

import android.widget.EditText;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.uas_mobile114.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Update extends AppCompatActivity {

    private EditText nama;
    private Button jam1,submit;
    private Spinner hari, ruang;
    private String jamlist;
    private int tjam,tmin;
    private String id = "";
    private FirebaseFirestore db =FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        nama = findViewById(R.id.namatxt);
        hari = findViewById(R.id.haritxt);
        jam1 = findViewById(R.id.jamtxt);
        ruang = findViewById(R.id.ruangtxt);
        submit = findViewById(R.id.submitbtn);

        //Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(), R.array.Haris, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        hari.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(getApplicationContext(), R.array.Kelass, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ruang.setAdapter(adapter1);

        submit.setOnClickListener(view -> {
            if (nama.getText().length() > 0) {
                saveData(nama.getText().toString(), jamlist, hari.getSelectedItem().toString(), ruang.getSelectedItem().toString());
            } else {
                Toast.makeText(getApplicationContext(), "Isi seluruh data", Toast.LENGTH_SHORT).show();
            }
        });

        Intent intent = getIntent();
        if (intent != null) {
            id = intent.getStringExtra("Id");
            nama.setText(intent.getStringExtra("Nama"));
            hari.setSelection(getHari(hari, intent.getStringExtra("Hari")));
            jam1.setText(intent.getStringExtra("Jam"));
            ruang.setSelection(getruang(ruang, intent.getStringExtra("Ruang")));
        }

    }

    private int getruang(Spinner kelas, String kelas1){
        for(int i=0;i<kelas.getCount();i++){
            if (kelas.getItemAtPosition(i).toString().equalsIgnoreCase(kelas1)){
                return i;
            }
        }
        return 0;
    }

    private int getHari(Spinner hari, String hari1){
        for(int i=0;i<hari.getCount();i++){
            if (hari.getItemAtPosition(i).toString().equalsIgnoreCase(hari1)){
                return i;
            }
        }
        return 0;
    }

    private void saveData(String nama, String hari, String jam, String ruang) {
        Map<String, Object> matkul = new HashMap<>();
        matkul.put("Mata Kuliah", nama);
        matkul.put("Hari", hari);
        matkul.put("Jam", jam);
        matkul.put("Ruang", ruang);

        db.collection("Mata Kuliah").document(id)
                .set(matkul)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Berhasil dimasukkan", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(getApplicationContext(), "Gagal memasukkan", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    public void popTimePicker(View view) {
        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {

            @Override
            public void onTimeSet(TimePicker view, int selectedHour, int selectedMinute) {
                tjam = selectedHour;
                tmin = selectedMinute;
                jamlist= String.format(Locale.getDefault(), "%02d:%02d",tjam,tmin);
                jam1.setText(String.format(Locale.getDefault(), "%02d:%02d",tjam,tmin));
            }
        };

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, onTimeSetListener, tjam, tmin, true);
        timePickerDialog.setTitle("Pilih Jam Mata Kuliah");
        timePickerDialog.show();
    }


}
